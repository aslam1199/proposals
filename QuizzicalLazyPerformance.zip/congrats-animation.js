// Firework Animation on Page Load
window.onload = function() {
    document.body.classList.add('celebration-fireworks');
};
